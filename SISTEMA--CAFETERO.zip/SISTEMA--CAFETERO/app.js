let inventario = [];

/* AGREGAR PRODUCTO */

function agregarProducto(){

const tipo = document.getElementById("tipoCafe").value;
const cantidad = document.getElementById("cantidadCafe").value;
const calidad = document.getElementById("calidadCafe").value;
const precio = document.getElementById("precioCafe").value;

if(tipo === "" || cantidad === "" || calidad === "" || precio === ""){

alert("Complete todos los campos");

return;

}

const producto = {

tipo,
cantidad,
calidad,
precio

};

inventario.push(producto);

mostrarInventario();

limpiarFormulario();

}

/* MOSTRAR */

function mostrarInventario(){

const tabla = document.getElementById("tablaInventario");

if(!tabla) return;

tabla.innerHTML = "";

inventario.forEach((producto,index)=>{

tabla.innerHTML += `

<tr>

<td>${producto.tipo}</td>

<td>${producto.cantidad} Kg</td>

<td>${producto.calidad}</td>

<td> $ ${Number(producto.precio).toLocaleString("es-CO")} COP </td>

<td>

<button class="delete-btn"
onclick="eliminarProducto(${index})">

Eliminar

</button>

</td>

</tr>

`;

});

}

/* ELIMINAR */

function eliminarProducto(index){

inventario.splice(index,1);

mostrarInventario();

}

/* LIMPIAR */

function limpiarFormulario(){

document.getElementById("tipoCafe").value = "";
document.getElementById("cantidadCafe").value = "";
document.getElementById("calidadCafe").value = "";
document.getElementById("precioCafe").value = "";

}

/* PRODUCTOR */

function productor(){

window.location.href = "inventario.html";

}

/* COMPRADOR */

function comprador(){

window.location.href = "clientes.html";

}

/* LOGIN */

function irLogin(){

window.location.href = "login.html";

}

/* INICIAR SESION */

function iniciarSesion(){

const correo = document.getElementById("correo").value;
const password = document.getElementById("password").value;

if(correo === "" || password === ""){

alert("Complete todos los campos");

return;

}

alert("Bienvenido al Sistema Cafetero");

window.location.href = "index.html";

}